return {
    result : 0,
    onAfterReturn : {
        "log" : "${baseUrl}"
    }
};